const Sequelize=require("sequelize")
const sequelize=require("../util/db")
const Customer=sequelize.define("customer",{
    id:{
        type:Sequelize.INTEGER,
        autoIncrement:true,
        allowNullValues:false,
        primaryKey:true
    },
    name:{
        type:Sequelize.STRING,
        allowNullValues:false
    },
    email:{
        type:Sequelize.STRING,
        allowNullValues:false
    }
})
module.exports=Customer