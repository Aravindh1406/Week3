
const sequelize=require("./util/db")
const Customer=require("./models/customer")
sequelize.sync({force:true})