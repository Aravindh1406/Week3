const sequelize=require("../util/db")
const Customer=require("../models/customer")
const { truncate } = require("fs")
const deleteCustomers=async(customerId)=>{
    try{
        await Customer.destroy({where:{},truncate:true})
        console.log("All Customers Deleted Successfully")
    }
    catch(err){
        console.log(err)
    }
}
deleteCustomers()