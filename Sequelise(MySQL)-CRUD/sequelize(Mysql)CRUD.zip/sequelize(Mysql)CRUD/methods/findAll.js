const sequelize=require("../util/db")
const Customer=require("../models/customer")
const findUsers=async()=>{
    try{
        const user=await Customer.findAll()
            console.log("Customers Found:",user)
    }
    catch(err){
        console.log(err)
    }
}
findUsers()