const sequelize=require("sequelize")
const Customer=require("../models/customer")
const name="Dolly"
const email="dolly@gmail.com"
const updateCustomer=async(customerId)=>{
    try{
        if(customerId){
            const beforeUpdation=await Customer.findOne({where:{id:customerId}})
            console.log("Updated Cutomer:",beforeUpdation)
            await Customer.update({name:name,email:email},{where:{id:customerId}})
            const updatedCustomer=await Customer.findOne({where:{id:customerId}})
            console.log("Updated Cutomer:",updatedCustomer)
        }
    }
    catch(err){
        console.log(err)
    }
}
updateCustomer(2)