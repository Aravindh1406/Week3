const sequelize=require("../util/db")
const Customer=require("../models/customer")
const createUser=async(name,email)=>{
    try{
        await Customer.create({name:name,email:email})
        console.log("New Customer Created..Name is:",name,"MailId is:",email)
    }
    catch(err){
        console.log(err)
    }
}
createUser("lilly","lilly@gmail.com")