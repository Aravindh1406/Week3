const sequelize=require("../util/db")
const Customer=require("../models/customer")
const deleteCustomer=async(customerId)=>{
    try{
        await Customer.destroy({where:{id:customerId}})
        if(!customerId){
            console.log("Customer Not Found")
        }else{
            console.log("Customer Deleted Successfully")
        }
    }
    catch(err){
        console.log(err)
    }
}
deleteCustomer(4)