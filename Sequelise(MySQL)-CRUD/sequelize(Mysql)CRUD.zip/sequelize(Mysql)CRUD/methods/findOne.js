const sequelize=require("../util/db")
const Customer=require("../models/customer")
const findUser=async(mailId)=>{
    try{
        const user=await Customer.findOne({where:{email:mailId}})
        if(!user){
            console.log("Customer Not Found")
        }else{
            console.log("Customer Found:",user)
        }
    }
    catch(err){
        console.log(err)
    }
}
findUser("bob@gmail.com")