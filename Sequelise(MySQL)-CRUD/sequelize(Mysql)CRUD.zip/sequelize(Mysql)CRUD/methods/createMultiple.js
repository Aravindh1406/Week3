const sequelize=require("../util/db")
const Customer=require("../models/customer")
const customers=[{name:"alice",email:"alice@gmail.com"},
    {name:"bob",email:"bob@gmail.com"},
    {name:"candy",email:"candy@gmail.com"}]
const createUser=async(users)=>{
    try{
        await Customer.bulkCreate(users)
        console.log("Created Customers:",users)
    }
    catch(err){
        console.log(err)
    }
}
createUser(customers)