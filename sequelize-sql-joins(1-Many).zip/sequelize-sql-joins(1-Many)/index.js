const sequelize=require("./config/db")
const {User,Post}=require("./models/model")
sequelize.sync({force:true,alter: true})