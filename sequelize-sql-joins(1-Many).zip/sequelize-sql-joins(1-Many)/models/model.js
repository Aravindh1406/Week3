const {DataTypes}=require("sequelize")
const sequelize=require("../config/db")
const User=sequelize.define("users",{
    id:{
        type:DataTypes.INTEGER,
        primaryKey:true,
        allowNull:false,
        autoIncrement:true
    },
    name:{
        type:DataTypes.STRING,
        allowNull:false
    },
    mail:{
        type:DataTypes.STRING,
        allowNull:true
    }
 },
  {
    timestamps:false
});
const Post=sequelize.define("posts",{
    id:{
        type:DataTypes.INTEGER,
        autoIncrement:true,
        allowNull:false,
        primaryKey:true
    },
    title:{
        type:DataTypes.STRING,

    },
    content:{
        type:DataTypes.TEXT
    },
},
    {
        timestamps:false
})
    
User.hasMany(Post)
Post.belongsTo(User)
module.exports={User,Post}
