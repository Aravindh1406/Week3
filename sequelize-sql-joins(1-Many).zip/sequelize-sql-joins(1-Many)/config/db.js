const Sequelize=require("sequelize")
const sequelize=new Sequelize("oneToMany","root","-Aravindh12",{
    dialect:"mysql",
    host:"localhost",
    logging:console.log
})
const checkConnection=async ()=>{
    try{
        await sequelize.authenticate()
        console.log("Connection Successful")
    }
    catch(err){
        console.log("connection Failed!!")
    }
}
checkConnection()
.then(()=>{
})
.catch((error)=>{
    console.log(error)
})
module.exports=sequelize
