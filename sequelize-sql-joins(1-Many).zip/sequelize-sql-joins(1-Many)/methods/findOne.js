const {User,Post}=require("../models/model")
const findUser=async()=>{
    try{
        const findUserWithPost=await User.findOne({where:{id:2},
        include:{
            model:Post,
            required:true
        }})
        if(!findUserWithPost){
            console.log("No user Found")
        }
        else{
            /*console.log("User Found")
            console.log(`Id is:${findUserWithPost.id}`)
            console.log(`Name is:${findUserWithPost.name}`)
            console.log(`Mail Id is:${findUserWithPost.mail}`)
            console.log(`Post is:${findUserWithPost.Post.title}`)
            console.log(`Content is:${findUserWithPost.Post.content}`)*/
            console.log(findUserWithPost)
        }
    }
    catch(err){
        console.log(err)
    }
}
findUser();