const {User,Profile}=require("../models/model")
const createUser=async()=>{
    try{
        const newUser=await User.create({name:"alice",mail:"alice123@gmail.com"})
        //await Post.create({title:"1st-Post",content:"Alice 1st Post",userId:newUser.id})
        //await Post.create({title:"2nd-Post",content:"Alice 2nd Post",userId:newUser.id})
    }
    catch(err){
        console.log(err)
    }
}
createUser();