const {User,Profile, Post}=require("../models/model")
const createUsers=async()=>{
    const newUsers=await User.bulkCreate([{name:"Bob",mail:"bob123@gmail.com"},{name:"Charile",mail:null},{name:"Dolly",mail:"dolly123@gmail.com"}])
    const userProfiles=await Post.bulkCreate([{title:"1st-Post",content:"Bob 1st Post",userId:newUsers[0].id},
                                                 {title:"1st-Post",content:"Charlie 1st Post",userId:newUsers[1].id},
                                                 {title:"1st-Post",content:"Dolly 1st Post",userId:newUsers[2].id},
                                                 {title:"2nd-Post",content:"Dolly 2nd Post",userId:newUsers[2].id},
                                                 {title:"1st-Post",content:"Candyy 1st Post"}])
    console.log("Users and Posts Created")
    /*newUsers.forEach((users)=>{
        const profile=userProfiles.find((p)=>
            p.userId===users.id)
        const bio=(profile)?profile.bio:"Profile Not Found"
        console.log("\n","User Id:",users.id,"\n","UserName is:",users.name,"\n","UserProfile is:",bio)
    })*/
}
createUsers()