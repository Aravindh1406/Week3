const sequelize=require("./config/db")
const {User,Profile}=require("./models/model")
sequelize.sync({force:true})