const { Sequelize } = require("sequelize")
const {User,Profile}=require("../models/model")
const findUsers=async()=>{
    try{
         const users=await Profile.findAll({
            include:{
                model:User,
                required:false,
            }
         })
       /*users.forEach((user)=>{
            console.log("Id:",user.id)
            console.log("User Name is:",user.name)
            console.log("User Mail Id:",user.mail)
            if((!user.Profile)){
                console.log("User Profile is:",null)
            }
            else{
                console.log("User Profile is:",user.Profile.bio)
            }
            
     }) */
        console.log(users)

    }
    catch(err){
        console.log(err)
    }
}
findUsers()