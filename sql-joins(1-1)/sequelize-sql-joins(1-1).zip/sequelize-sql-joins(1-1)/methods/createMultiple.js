const {User,Profile}=require("../models/model")
const createUsers=async()=>{
    const newUsers=await User.bulkCreate([{name:"Bob",mail:"bob123@gmail.com"},{name:"Charile",mail:null},{name:"Dolly",mail:"dolly123@gmail.com"}])
    const userProfiles=await Profile.bulkCreate([{bio:"Andriod Developer",userId:newUsers[0].id},
                                                 {bio:null,userId:newUsers[1].id},
                                                 {bio:"Product Engineer",userId:newUsers[2].id},
                                                 {bio:"Data Scientist"}])
    console.log("Users Created")
    newUsers.forEach((users)=>{
        const profile=userProfiles.find((p)=>
            p.userId===users.id)
        const bio=(profile)?profile.bio:"Profile Not Found"
        console.log("\n","User Id:",users.id,"\n","UserName is:",users.name,"\n","UserProfile is:",bio)
    })
}
createUsers()