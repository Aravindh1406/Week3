const {User,Profile}=require("../models/model")
const createUser=async()=>{
    try{
        const newUser=await User.create({name:"alice",mail:"alice123@gmail.com"})
        //const newProfile=await Profile.create({bio:null,userId:newUser.id})
        console.log("\n","New User Created" ,"\n","id is:",newUser.id,"\n","Name is:",newUser.name,"\n","Mail is:",newUser.mail)
    }
    catch(err){
        console.log(err)
    }
}
createUser();