const {User,Profile}=require("../models/model")
const findUser=async()=>{
    try{
        const findUserWithProfile=await User.findOne({where:{id:2},
        include:{
            model:Profile,
            required:true
        }})
        if(!findUserWithProfile){
            console.log("No user Found")
        }
        else{
            console.log("User Found")
            console.log(`Id is:${findUserWithProfile.id}`)
            console.log(`Name is:${findUserWithProfile.name}`)
            console.log(`Mail Id is:${findUserWithProfile.mail}`)
            console.log(`Profile is:${findUserWithProfile.Profile.bio}`)
        }
    }
    catch(err){
        console.log(err)
    }
}
findUser();