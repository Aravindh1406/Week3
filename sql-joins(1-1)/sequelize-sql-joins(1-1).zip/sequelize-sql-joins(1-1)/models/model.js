const {DataTypes}=require("sequelize")
const sequelize=require("../config/db")
const { timeStamp } = require("node:console");
const { title } = require("node:process");
const { type } = require("node:os");
const User=sequelize.define("users",{
    id:{
        type:DataTypes.INTEGER,
        primaryKey:true,
        allowNull:false,
        autoIncrement:true
    },
    name:{
        type:DataTypes.STRING,
        allowNull:false
    },
    mail:{
        type:DataTypes.STRING,
        allowNull:true
    }
 },
  {
    timestamps:false
});

const Profile=sequelize.define("Profiles",{
    id:{
        type:DataTypes.INTEGER,
        primaryKey:true,
        allowNull:false,
        autoIncrement:true
    },
    bio:{
        type:DataTypes.TEXT,
        allowNull:true
    }
 },
 {
    timestamps:false 
});
const Post=sequelize.define("posts",{
    id:{
        type:DataTypes.INTEGER,
        autoIncrement:true,
        allowNull:false,
        primaryKey:true
    },
    title:{
        type:DataTypes.STRING,

    },
    content:{
        type:DataTypes.TEXT
    },
},
    {
        timestamps:false
})
    
User.hasOne(Profile)
Profile.belongsTo(User)
User.hasMany(Post)
Post.belongsTo(User)
module.exports={User,Profile}
